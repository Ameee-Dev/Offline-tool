package com.example.toolbox

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val dark = isSystemInDarkTheme()
            val colors = when {
                Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = colors) {
                // Android 13+ 需要通知权限，才能在通知栏显示播放控制
                val askNotification = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33) askNotification.launch(Manifest.permission.POST_NOTIFICATIONS)
                }

                var tab by remember { mutableIntStateOf(0) }
                val mixer = remember { MixerState(ctx) }
                val player = rememberPlayerState()

                Scaffold(bottomBar = {
                    NavigationBar {
                        listOf("🎬" to "音视频合成", "🎵" to "音乐播放器").forEachIndexed { i, (icon, label) ->
                            NavigationBarItem(tab == i, { tab = i }, { Text(icon) }, label = { Text(label) })
                        }
                    }
                }) { pad ->
                    Surface(Modifier.padding(pad).fillMaxSize()) {
                        if (tab == 0) MixerScreen(mixer) else PlayerScreen(player)
                    }
                }
            }
        }
    }
}
