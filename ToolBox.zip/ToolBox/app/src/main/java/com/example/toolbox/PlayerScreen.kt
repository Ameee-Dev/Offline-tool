package com.example.toolbox

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 工具2的全部状态：曲库 + 与后台播放服务的连接。 */
class PlayerState(ctx: Context) {
    private val app = ctx.applicationContext
    private val prefs = app.getSharedPreferences("lib", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var ctrl: MediaController? = null

    val tracks = mutableStateListOf<Track>()
    var index by mutableIntStateOf(-1)
    var playing by mutableStateOf(false)
    var pos by mutableLongStateOf(0L)
    var dur by mutableLongStateOf(0L)
    var loading by mutableStateOf(false)

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    private fun sync(p: Player) {
        playing = p.isPlaying
        index = tracks.indexOfFirst { it.uri.toString() == p.currentMediaItem?.mediaId }
        dur = if (p.duration > 0) p.duration else tracks.getOrNull(index)?.durationMs ?: 0L
        pos = p.currentPosition
    }

    private fun item(t: Track): MediaItem = MediaItem.Builder()
        .setUri(t.uri)
        .setMediaId(t.uri.toString())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(t.album)
                .apply { t.art?.let { setArtworkData(it, MediaMetadata.PICTURE_TYPE_FRONT_COVER) } }
                .build()
        )
        .build()

    /** 导入文件（也用于启动时恢复上次的曲库） */
    fun add(uris: List<Uri>) {
        uris.forEach {
            runCatching { app.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        val have = tracks.map { it.uri }.toSet()
        scope.launch {
            loading = true
            val fresh = withContext(Dispatchers.IO) {
                uris.distinct().filter { it !in have }.mapNotNull { loadTrack(app, it) }
            }
            val c = ctrl
            if (c != null && c.mediaItemCount == tracks.size) c.addMediaItems(fresh.map { item(it) })
            tracks.addAll(fresh)
            save()
            ctrl?.let { sync(it) }
            loading = false
        }
    }

    fun remove(i: Int) {
        val t = tracks[i]
        val c = ctrl
        if (c != null) {
            if (c.currentMediaItem?.mediaId == t.uri.toString()) {
                c.stop()
                c.clearMediaItems()
            } else if (i < c.mediaItemCount && c.getMediaItemAt(i).mediaId == t.uri.toString()) {
                c.removeMediaItem(i)
            }
        }
        tracks.removeAt(i)
        save()
        ctrl?.let { sync(it) }
    }

    private fun save() {
        prefs.edit().putString("uris", tracks.joinToString("\n") { it.uri.toString() }).apply()
    }

    fun play(i: Int) {
        val c = ctrl ?: return
        val same = c.mediaItemCount == tracks.size &&
            tracks.indices.all { c.getMediaItemAt(it).mediaId == tracks[it].uri.toString() }
        if (same) c.seekToDefaultPosition(i) else c.setMediaItems(tracks.map { item(it) }, i, 0L)
        c.prepare()
        c.play()
    }

    fun toggle() {
        val c = ctrl ?: return
        when {
            c.isPlaying -> c.pause()
            c.mediaItemCount == 0 -> if (tracks.isNotEmpty()) play(0)
            else -> c.play()
        }
    }

    fun next() { ctrl?.seekToNextMediaItem() }
    fun prev() { ctrl?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { ctrl?.seekTo(ms) }
    fun tick() { ctrl?.let { pos = it.currentPosition } }

    fun release() {
        scope.cancel()
        ctrl?.release()
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching { future.get() }.onSuccess { c ->
                ctrl = c
                c.addListener(listener)
                sync(c)
            }
        }, ContextCompat.getMainExecutor(app))
        add(prefs.getString("uris", "")!!.split("\n").filter { it.isNotBlank() }.map { Uri.parse(it) })
    }
}

@Composable
fun rememberPlayerState(): PlayerState {
    val ctx = LocalContext.current
    val s = remember { PlayerState(ctx) }
    DisposableEffect(Unit) { onDispose { s.release() } }
    return s
}

@Composable
fun PlayerScreen(s: PlayerState) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { s.add(it) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("音乐播放器", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall)
            Button({ pick.launch(arrayOf("audio/*", "application/ogg")) }) { Text("导入音乐") }
        }
        if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        if (s.tracks.isEmpty() && !s.loading) {
            Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) { Text("点右上角「导入音乐」添加 MP3 / M4A / FLAC 等文件") }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(s.tracks, key = { _, t -> t.uri.toString() }) { i, t ->
                    TrackRow(t, i == s.index, onRemove = { s.remove(i) }) { s.play(i) }
                }
            }
        }

        s.tracks.getOrNull(s.index)?.let { NowPlaying(s, it) }
    }
}

@Composable
private fun TrackRow(t: Track, active: Boolean, onRemove: () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(if (active) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(12.dp, 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cover(t, 60.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
            Text("${t.artist} · ${t.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            Text(
                "${t.genre} · ${t.format} · ${fmtSize(t.size)} · ${fmtTime(t.durationMs)}",
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        TextButton(onRemove) { Text("✕") }
    }
}

@Composable
private fun Cover(t: Track, size: Dp) {
    val m = Modifier.size(size).clip(RoundedCornerShape(8.dp))
    val bmp = t.cover
    if (bmp != null) {
        Image(bmp.asImageBitmap(), null, m, contentScale = ContentScale.Crop)
    } else {
        Box(m.background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) { Text("🎵") }
    }
}

@Composable
private fun NowPlaying(s: PlayerState, t: Track) {
    var drag by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(s.playing) {
        while (s.playing) {
            s.tick()
            delay(500)
        }
    }
    Surface(tonalElevation = 6.dp) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Cover(t, 52.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                }
                TextButton(s::prev) { Text("⏮") }
                Button(s::toggle) { Text(if (s.playing) "⏸" else "▶") }
                TextButton(s::next) { Text("⏭") }
            }
            val shown = drag ?: s.pos.toFloat()
            Slider(
                value = shown,
                onValueChange = { drag = it },
                onValueChangeFinished = {
                    drag?.let { s.seek(it.toLong()) }
                    drag = null
                },
                valueRange = 0f..maxOf(s.dur, 1L).toFloat()
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmtTime(shown.toLong()), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                Text(fmtTime(s.dur), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
