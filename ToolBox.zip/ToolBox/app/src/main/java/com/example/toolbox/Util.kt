package com.example.toolbox

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

fun nameOf(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    } ?: uri.lastPathSegment ?: "未知"

fun sizeOf(ctx: Context, uri: Uri): Long =
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
        if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else 0L
    } ?: 0L

fun <T> withRetriever(ctx: Context, uri: Uri, f: (MediaMetadataRetriever) -> T): T {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        return f(r)
    } finally {
        r.release()
    }
}

fun durationOf(ctx: Context, uri: Uri): Long = runCatching {
    withRetriever(ctx, uri) { it.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
}.getOrDefault(0L)

fun fmtSize(b: Long): String =
    if (b >= 1_048_576L) "%.1f MB".format(b / 1_048_576.0) else "${b / 1024} KB"

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
