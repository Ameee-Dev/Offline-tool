package com.example.toolbox

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.ByteArrayOutputStream

class Track(
    val uri: Uri,
    val name: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val size: Long,
    val durationMs: Long,
    val cover: Bitmap?,   // 界面显示用
    val art: ByteArray?   // 通知栏/锁屏封面用（JPEG）
) {
    val format: String get() = name.substringAfterLast('.', "").uppercase()
}

/** 读取音频的标题、作者、专辑、类别、大小、时长和内嵌封面。读不到文件返回 null。 */
fun loadTrack(ctx: Context, uri: Uri): Track? = runCatching {
    val name = nameOf(ctx, uri)
    val size = sizeOf(ctx, uri)
    val fallbackTitle = name.substringBeforeLast('.')
    runCatching {
        withRetriever(ctx, uri) { r ->
            fun m(key: Int) = r.extractMetadata(key)?.takeIf { it.isNotBlank() }
            val c = cover(r.embeddedPicture)
            Track(
                uri, name,
                m(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: fallbackTitle,
                m(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?: m(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST) ?: "未知作者",
                m(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "未知专辑",
                m(MediaMetadataRetriever.METADATA_KEY_GENRE) ?: "未知类别",
                size,
                m(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                c?.first, c?.second
            )
        }
    }.getOrElse {
        if (size > 0) Track(uri, name, fallbackTitle, "未知作者", "未知专辑", "未知类别", size, 0L, null, null) else null
    }
}.getOrNull()

/** 把封面缩到 256px 以内，既省内存，也避免通知栏传输过大。 */
private fun cover(raw: ByteArray?): Pair<Bitmap, ByteArray>? {
    raw ?: return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
    var s = 1
    while (bounds.outWidth / (s * 2) >= 256) s *= 2
    val b = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = s })
        ?: return null
    val k = 256f / maxOf(b.width, b.height)
    val bmp = if (k < 1f) {
        Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
    } else b
    val jpg = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
    return bmp to jpg
}
