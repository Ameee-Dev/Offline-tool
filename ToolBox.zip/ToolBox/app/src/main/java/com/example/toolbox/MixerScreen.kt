package com.example.toolbox

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/** 工具1的全部状态和逻辑。放在 Activity 级别，切换标签页不会中断处理。 */
class MixerState(ctx: Context) {
    private val app = ctx.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private val holder = ProgressHolder()
    private var transformer: Transformer? = null
    private var videoMs = 0L
    private var audioMs = 0L

    var video by mutableStateOf<Uri?>(null)
    var audio by mutableStateOf<Uri?>(null)
    var videoName by mutableStateOf("")
    var audioName by mutableStateOf("")
    var videoHasAudio by mutableStateOf(false)
    var replace by mutableStateOf(true)          // true=替换原音频，false=与原音频合并
    var saveTo by mutableStateOf<Uri?>(null)     // null=保存到系统相册
    var progress by mutableFloatStateOf(-1f)     // <0 表示空闲
    var message by mutableStateOf("")

    fun setVideo(u: Uri) {
        video = u
        videoName = nameOf(app, u)
        message = ""
        runCatching {
            withRetriever(app, u) { r ->
                videoHasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
                videoMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            }
        }.onFailure { message = "无法读取这个视频" }
    }

    fun setAudio(u: Uri) {
        audio = u
        audioName = nameOf(app, u)
        audioMs = durationOf(app, u)
        message = ""
    }

    fun confirmText(): String = when {
        !videoHasAudio -> "视频「${videoName}」本来没有音频，将为它添加「${audioName}」。是否继续？"
        replace -> "将用「${audioName}」替换视频「${videoName}」的原有音频，原音频不会保留。是否继续？"
        else -> "将把「${audioName}」与视频「${videoName}」的原有音频合并在一起。是否继续？"
    }

    private val tick = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) progress = holder.progress / 100f
            handler.postDelayed(this, 300)
        }
    }

    fun run() {
        val v = video ?: return
        val a = audio ?: return
        val out = File(app.cacheDir, "out.mp4").also { it.delete() }

        val videoItem = EditedMediaItem.Builder(MediaItem.fromUri(v))
            .setRemoveAudio(replace && videoHasAudio)
            .build()

        // 音频比视频长就截到视频长度；更短则其余部分无声
        val audioMedia = MediaItem.Builder().setUri(a).apply {
            if (videoMs > 0 && audioMs > videoMs) {
                setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder().setEndPositionMs(videoMs).build()
                )
            }
        }.build()
        val audioItem = EditedMediaItem.Builder(audioMedia).build()

        val composition = Composition.Builder(
            EditedMediaItemSequence(videoItem),
            EditedMediaItemSequence(audioItem)
        ).build()

        val t = Transformer.Builder(app)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    save(out)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    finish("处理失败：${exportException.message}")
                }
            })
            .build()

        transformer = t
        progress = 0f
        message = "处理中…"
        t.start(composition, out.absolutePath)
        handler.post(tick)
    }

    fun cancel() {
        transformer?.cancel()
        finish("已取消")
    }

    private fun save(f: File) {
        progress = 1f
        message = "正在保存…"
        val dest = saveTo ?: app.contentResolver.insert(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "toolbox_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ToolBox")
            }
        )
        if (dest == null) {
            finish("无法创建保存位置")
            return
        }
        val toGallery = saveTo == null
        Thread {
            val ok = runCatching {
                app.contentResolver.openOutputStream(dest)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            }.isSuccess
            f.delete()
            handler.post {
                finish(
                    when {
                        !ok -> "保存失败"
                        toGallery -> "完成！已保存到系统相册（Movies/ToolBox）"
                        else -> "完成！已保存到你选择的位置"
                    }
                )
            }
        }.start()
    }

    private fun finish(msg: String) {
        handler.removeCallbacks(tick)
        transformer = null
        progress = -1f
        message = msg
    }
}

@Composable
fun MixerScreen(s: MixerState) {
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(s::setVideo) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(s::setAudio) }
    val pickOut = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { if (it != null) s.saveTo = it }
    var confirm by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val saveName = remember(s.saveTo) { s.saveTo?.let { nameOf(ctx, it) } }
    val busy = s.progress >= 0f

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("音视频合成", style = MaterialTheme.typography.headlineSmall)

        PickRow("视频", s.videoName) { pickVideo.launch(arrayOf("video/*")) }
        PickRow("音频", s.audioName) { pickAudio.launch(arrayOf("audio/*", "application/ogg")) }

        if (s.video != null && s.audio != null) {
            if (s.videoHasAudio) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(s.replace, { s.replace = true }, { Text("替换原音频") })
                    FilterChip(!s.replace, { s.replace = false }, { Text("与原音频合并") })
                }
            } else {
                Text("这个视频没有音频，将直接添加所选音频")
            }
        }

        Text(
            "保存位置：" + (saveName ?: "系统相册（默认）"),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ pickOut.launch("toolbox_${System.currentTimeMillis()}.mp4") }) { Text("选择保存路径") }
            if (s.saveTo != null) TextButton({ s.saveTo = null }) { Text("恢复为相册") }
        }

        Button(
            onClick = { confirm = true },
            enabled = s.video != null && s.audio != null && !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("开始处理") }

        if (busy) {
            LinearProgressIndicator(progress = { s.progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            TextButton(s::cancel) { Text("取消处理") }
        }
        if (s.message.isNotEmpty()) Text(s.message, color = MaterialTheme.colorScheme.primary)

        Text(
            "提示：音频比视频长会被截断；比视频短，剩余部分无声。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("请确认") },
            text = { Text(s.confirmText()) },
            confirmButton = { TextButton({ confirm = false; s.run() }) { Text("确定") } },
            dismissButton = { TextButton({ confirm = false }) { Text("取消") } }
        )
    }
}

@Composable
private fun PickRow(label: String, name: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Button(onClick) { Text("选择$label") }
        Spacer(Modifier.width(12.dp))
        Text(name.ifEmpty { "未选择" }, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
